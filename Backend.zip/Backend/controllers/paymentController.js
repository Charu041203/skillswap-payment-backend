const paymentService = require("../services/paymentService");
const { verify } = require("../utils/verifyPayment");

// POST /api/payments/create-order
// Step 1 — Create a Razorpay order before showing payment popup
exports.createOrder = async (req, res) => {
  try {
    const { amount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: "Valid amount is required" });
    }

    const order = await paymentService.createOrder(amount);
    res.json({
      success: true,
      orderId: order.id,       // Send this to frontend
      amount: order.amount,    // In paise
      currency: order.currency,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payments/verify
// Step 2 — Verify payment signature after user pays
exports.verifyAndStore = async (req, res) => {
  try {
    const { order_id, payment_id, signature, userId, amount } = req.body;

    // Check all required fields are present
    if (!order_id || !payment_id || !signature || !userId || !amount) {
      return res.status(400).json({ error: "All fields are required" });
    }

    // Verify the payment signature (security check)
    const isValid = verify(order_id, payment_id, signature);
    if (!isValid) {
      return res.status(400).json({ error: "Invalid payment signature" });
    }

    // Store transaction in DB
    const transaction = await paymentService.storeTransaction(
      userId,
      amount,
      order_id,
      payment_id
    );

    // Apply commission on this payment
    await paymentService.applyCommission(transaction._id, amount);

    res.json({
      success: true,
      message: "Payment verified and stored",
      transactionId: transaction._id,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payments/refund
// Refund a payment
exports.refund = async (req, res) => {
  try {
    const { transactionId } = req.body;

    if (!transactionId) {
      return res.status(400).json({ error: "transactionId is required" });
    }

    const refund = await paymentService.refundTransaction(transactionId);
    res.json({
      success: true,
      message: "Refund processed successfully",
      refund,
    });
  } catch (err) {
    // Handle specific errors nicely
    if (err.message === "Already refunded") {
      return res.status(400).json({ error: "This transaction is already refunded" });
    }
    if (err.message === "Transaction not found") {
      return res.status(404).json({ error: "Transaction not found" });
    }
    res.status(500).json({ error: err.message });
  }
};

// POST /api/payments/webhook
// Razorpay calls this automatically when payment status changes
exports.webhook = async (req, res) => {
  try {
    const secret = process.env.RAZORPAY_SECRET;
    const crypto = require("crypto");

    // Verify the webhook is actually from Razorpay
    const shasum = crypto.createHmac("sha256", secret);
    shasum.update(JSON.stringify(req.body));
    const digest = shasum.digest("hex");

    if (digest !== req.headers["x-razorpay-signature"]) {
      return res.status(400).json({ error: "Invalid webhook signature" });
    }

    const event = req.body.event;

    // Handle different webhook events
    if (event === "payment.captured") {
      console.log("Payment captured:", req.body.payload.payment.entity.id);
      // You can add more logic here later
    }

    if (event === "payment.failed") {
      console.log("Payment failed:", req.body.payload.payment.entity.id);
      // You can update transaction status to failed here
    }

    res.json({ received: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};